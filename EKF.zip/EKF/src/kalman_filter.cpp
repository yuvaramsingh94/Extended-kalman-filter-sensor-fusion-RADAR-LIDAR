#include "kalman_filter.h"
#include <iostream>
using namespace std;
using Eigen::MatrixXd;
using Eigen::VectorXd;

KalmanFilter::KalmanFilter() {}

KalmanFilter::~KalmanFilter() {}

void KalmanFilter::Init(VectorXd &x_in, MatrixXd &P_in, MatrixXd &F_in,
                        MatrixXd &H_in, MatrixXd &R_in, MatrixXd &Q_in) {
  x_ = x_in;
  P_ = P_in;
  F_ = F_in;
  H_ = H_in;
  R_ = R_in;
  Q_ = Q_in;
}

void KalmanFilter::Predict() {
  /**
  TODO:
    * predict the state
  */
  x_ = F_ * x_ ;
  P_ = F_*P_*F_.transpose() + Q_;


}

void KalmanFilter::Update(const VectorXd &z) {//lider
  /**
  TODO:
    * update the state by using Kalman Filter equations
  */
  //cout <<"into main calc 16 "<<endl;
  VectorXd Y(4);
  //cout <<"into main calc 17 "<<endl;
  Y = z - H_*x_;
  //cout <<"into main calc 18 "<<endl;
  MatrixXd S  = H_*P_*H_.transpose() + R_;
  //cout <<"into main calc 19 "<<endl;
  MatrixXd K = P_*H_.transpose()*S.inverse();
  //cout <<"into main calc 20 "<<endl;
  long x_size = x_.size();
  //cout <<"into main calc 21 "<<endl;
  MatrixXd I = MatrixXd::Identity(x_size, x_size);
  //cout <<"into main calc 22 "<<endl;
  x_ = x_ + (K*Y);
  //cout <<"into main calc 23 "<<endl;
  P_ = (I - K*H_)*P_;
  //cout <<"into main calc 24 "<<endl;


}

void KalmanFilter::UpdateEKF(const VectorXd &z) {
  /**
  TODO:
    * update the state by using Extended Kalman Filter equations
  */
    //cout <<"into main calc 6 "<<endl;

  float px = x_(0);
  float py = x_(1);
  float vx = x_(2);
  float vy = x_(3);
  if ((py>0.23)||(py<-3.0001)){
    //cout <<"into main calc 7 "<<endl;
    VectorXd hx(3); 
    MatrixXd Hj = tool.CalculateJacobian(x_);
    //cout <<"into main calc 8 "<<endl;
    float sq = sqrt(px*px + py*py);
    hx << sq,atan2(py,px),(px*vx +py*vy)/sq;
    //cout <<"hx "<<hx <<endl;
    //cout <<"size of z"<< z <<endl;
    VectorXd Y = z - hx;
    //cout <<"y "<<Y <<endl;

    //cout <<"into main calc 10 "<<endl;
    MatrixXd S = Hj*P_*Hj.transpose() +R_;
    //cout <<"into main calc 11 "<<endl;
    MatrixXd K = P_*Hj.transpose()*S.inverse();
    //cout <<"into main calc 12 "<<endl;
    long x_size = x_.size();
    MatrixXd I = MatrixXd::Identity(x_size, x_size);
    //cout <<"into main calc 13 "<<endl;
    x_ = x_ + K*Y;
    //cout <<"into main calc 14 "<<endl;
    P_ = (I-K*Hj)*P_;
    //cout <<"into main calc 15"<<endl;

  }
}
